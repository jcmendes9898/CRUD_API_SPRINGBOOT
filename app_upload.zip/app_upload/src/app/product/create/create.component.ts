import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup } from '@angular/forms';
import { MatDialogRef } from '@angular/material/dialog';
import { RxwebValidators } from '@rxweb/reactive-form-validators';

@Component({
  selector: 'app-create',
  templateUrl: './create.component.html',
  styleUrls: ['./create.component.css']
})
export class CreateComponent implements OnInit {

  constructor(
    private fb: FormBuilder,
    private dialogRef: MatDialogRef<CreateComponent>,
  ) { }

  form: FormGroup;
  name: string;
  price: number;

  ngOnInit() {
    this.form = this.fb.group({
      name: [this.name, []],
      price: [this.price, [RxwebValidators.numeric({ allowDecimal: true, isFormat: true })]]
    });
  }

  save() {
    console.table(this.form)
    if (this.form.status === 'VALID' && this.form.value.name != null && this.form.value.price != null) {
      this.dialogRef.close(this.form.value);
    }
  }

  close() {
    this.dialogRef.close();
  }

}

import { Component, Inject, OnInit } from '@angular/core';
import { FormBuilder, FormGroup } from '@angular/forms';
import { MatDialogRef, MAT_DIALOG_DATA } from '@angular/material/dialog';
import { RxwebValidators } from '@rxweb/reactive-form-validators';

@Component({
  selector: 'app-update',
  templateUrl: './update.component.html',
  styleUrls: ['./update.component.css']
})
export class UpdateComponent implements OnInit {

  constructor(
    private fb: FormBuilder,
    private dialogRef: MatDialogRef<UpdateComponent>,
    @Inject(MAT_DIALOG_DATA) data
  ) { 
    this.name = data.name;
    this.price = data.price;
  }

  form: FormGroup;
  name: string;
  price: number;

  ngOnInit() {
    this.form = this.fb.group({
      name: [this.name, []],
      price: [this.price, [RxwebValidators.numeric({ allowDecimal: true, isFormat: true })]]
    });
  }

  save() {
    console.table(this.form)
    if (this.form.status === 'VALID' && this.form.value.name != null && this.form.value.price != null) {
      this.dialogRef.close(this.form.value);
    }
  }

  close() {
    this.dialogRef.close();
  }

}

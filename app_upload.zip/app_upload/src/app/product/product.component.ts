import { Component, EventEmitter, Input, OnInit, Output } from '@angular/core';
import { Product, ProductDetail } from '../_shared/_model/product.model';
import { ProductService } from '../_shared/_services/product.service';
import { MatDialog, MatDialogConfig } from '@angular/material/dialog';
import { CreateComponent } from './create/create.component';
import { UpdateComponent } from './update/update.component';

@Component({
  selector: 'app-product',
  templateUrl: './product.component.html',
  styleUrls: ['./product.component.css']
})
export class ProductComponent implements OnInit {

  @Input() jwt: string;
  @Output() resp = new EventEmitter();

  constructor(
    private prodService: ProductService,
    private matDialog: MatDialog
  ) { }

  ngOnInit(): void {
    console.log("TOKEN-> " + this.jwt)
    this.getAllProducts();
  }

  resp_error() {
    console.log("ESP_ERROR")
    this.resp.emit();
    this.resp = null;
  }

  productsList: Product[] = [];
  getAllProducts() {
    this.prodService.getAllProducts(this.jwt).subscribe(resp => {
      console.table(resp)
      this.productsList = resp;
    }, error => {
      console.log("error-> " + error)
      this.resp_error();
    })
  }

  onRefresh() {
    this.getAllProducts();
  }

  onDelete(prod: Product) {
    this.prodService.deleteProduct(this.jwt, prod.id_s).subscribe(resp => {
      console.table(resp)
      this.getAllProducts();
    }, error => {
      console.log("error-> " + error)
      this.resp_error();
    })
  }

  addProduct_modal() {
    const dialogConfig = new MatDialogConfig();
    dialogConfig.disableClose = false;
    dialogConfig.id = "create-component";
    const modalCreate = this.matDialog.open(CreateComponent, dialogConfig);
    modalCreate.afterClosed().subscribe(
      (data: ProductDetail) => {
        if (data && data.name != null && data.price != null) {
          console.log("Dialog output:", data)
          this.addProduct(data)
        }
      }
    );
  }

  addProduct(prod: ProductDetail) {
    this.prodService.addProduct(this.jwt, prod).subscribe(resp => {
      console.table(resp)
      this.getAllProducts();
    }, error => {
      console.log("error-> " + error)
      this.resp_error();
    })
  }

  updateProduct_modal(prod: Product) {
    const dialogConfig = new MatDialogConfig();
    dialogConfig.disableClose = false;
    dialogConfig.id = "update-component";

    dialogConfig.data = {
      name: prod.name,
      price: prod.price
  };

    const modalCreate = this.matDialog.open(UpdateComponent, dialogConfig);
    modalCreate.afterClosed().subscribe(
      (data: ProductDetail) => {
        if (data && data.name != null && data.price != null) {
          console.log("Dialog output:", data)
          this.updateProduct(data, prod.id_s)
        }
      }
    );
  }

  updateProduct(prod: ProductDetail, id) {
    this.prodService.updateProduct(this.jwt, prod, id).subscribe(resp => {
      console.table(resp)
      this.getAllProducts();
    }, error => {
      console.log("error-> " + error)
      this.resp_error();
    })
  }


}

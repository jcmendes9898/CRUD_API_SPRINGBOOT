import { Component, OnInit } from '@angular/core';
import { NgbNavConfig } from '@ng-bootstrap/ng-bootstrap';
import { AuthService } from './_shared/_services/auth.service';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent implements OnInit {

  constructor(
    config: NgbNavConfig,
    private authService: AuthService
  ) {
    config.destroyOnHide = false;
    config.roles = false;
  }

  ngOnInit(): void {
    this.getToken();
  }

  getToken() {
    //this.authService.authentication()
  }

  isLoggedIn = false;
  username = "";
  password = "";
  jwt = "";
  onAuth() {
    console.log(this.username);
    console.log(this.password);
    this.authService.authentication(this.username, this.password).subscribe(resp => {
      if (resp.jwt) {
        this.jwt = resp.jwt
        this.isLoggedIn = true;
      }
    }, error => {
      console.log(error)
    })
  }

  public onRespError(isLoggedIn: boolean): void {
    console.log("ERROR")
    this.isLoggedIn = false;
  }

}

import { Component, EventEmitter, Input, OnInit, Output } from '@angular/core';
import { MatDialog, MatDialogConfig } from '@angular/material/dialog';
import { forkJoin } from 'rxjs';
import { Order, OrderDetail, ProductOrder } from '../_shared/_model/order.model';
import { OrderService } from '../_shared/_services/order.service';
import { CreateComponent } from './create/create.component';

@Component({
  selector: 'app-order',
  templateUrl: './order.component.html',
  styleUrls: ['./order.component.css']
})
export class OrderComponent implements OnInit {

  @Input() jwt: string;
  @Output() resp = new EventEmitter();

  constructor(
    private orderService: OrderService,
    private matDialog: MatDialog
  ) { }

  ngOnInit() {
    this.getAllOrders()
  }

  resp_error() {
    console.log("ESP_ERROR")
    this.resp.emit();
    this.resp = null;
  }

  orderList: Order[] = [];
  getAllOrders() {
    this.orderService.getAllOrders(this.jwt).subscribe(resp => {
      console.table(resp)
      this.orderList = resp;
      this.orderList_tmp = resp;
    }, error => {
      console.log("error-> " + error)
      this.resp_error();
    })
  }

  onRefresh() {
    this.getAllOrders();
  }

  onDelete(order: Order) {
    this.orderService.deleteOrder(this.jwt, order.id_s).subscribe(resp => {
      console.table(resp)
      this.getAllOrders();
    }, error => {
      console.log("error-> " + error)
      this.resp_error();
    })
  }

  addOrder_modal() {
    console.log("addOrder_modal")
    const dialogConfig = new MatDialogConfig();
    dialogConfig.disableClose = false;
    dialogConfig.id = "create-component";
    dialogConfig.width = "650px";

    dialogConfig.data = {
      jwt: this.jwt
    };

    const modalCreate = this.matDialog.open(CreateComponent, dialogConfig);
    modalCreate.afterClosed().subscribe(
      (data: OrderDetail) => {
        if (data && data.email != null && data.total != null && data.products != null) {
          console.table(data)
          this.addOrder(data)
        }
      }
    );
  }

  addOrder(order: OrderDetail) {
    this.orderService.addOrder(this.jwt, order).subscribe(resp => {
      console.table(resp)
      this.getAllOrders();
    }, error => {
      console.log("error-> " + error)
      this.resp_error();
    })
  }

  selectedOrder: Order;
  onSelected(order: Order) {
    this.selectedOrder = order;
  }

  async onDeleteOrder(order: Order) {
    this.selectedOrder = null;
    let arrayID = [];
    order.products.forEach(prod => {
      let tmp = this.orderService.deleteProdOrder(this.jwt, prod.id_s)
      arrayID.push(tmp);
      console.log("FOREACH")
    })
    console.log("SAIU")
    forkJoin(arrayID).subscribe(resp => {
      console.log(resp)
      this.deleteOrder(order.id_s)

    }, error => {
      console.log("error-> " + error)
      this.resp_error();
    })
  }

  deleteOrder(id) {
    this.orderService.deleteOrder(this.jwt, id).subscribe(
      async resp => {
        console.table(resp)
        this.getAllOrders();
      }, error => {
        console.log("error-> " + error)
        this.resp_error();
      })
  }

  dateFrom: Date;
  dateTo: Date;
  orderList_tmp: Order[] = [];
  async getBetweenDates() {
    console.log("dateFrom " + this.dateFrom + ", dateTo: " + this.dateTo)
    if (this.dateFrom == null || this.dateTo == null) return;

    let tmp_array = []
    this.orderList_tmp.forEach(order => {
      let tmp_dt = new Date(order.date_created)
      console.log(tmp_dt)
      if (this.dateFrom.getTime() <= tmp_dt.getTime() && tmp_dt.getTime() <= this.dateTo.getTime()) {
        tmp_array.push(order);
      }
    })
    this.orderList = tmp_array;
  }

  async clearDates(){
    this.dateFrom = null;
    this.dateTo = null;
  }

}

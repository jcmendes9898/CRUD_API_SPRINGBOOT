import { Component, Inject, OnInit } from '@angular/core';
import { MatDialogRef, MAT_DIALOG_DATA } from '@angular/material/dialog';
import { OrderDetail, ProductOrder } from 'src/app/_shared/_model/order.model';
import { Product } from 'src/app/_shared/_model/product.model';
import { ProductService } from 'src/app/_shared/_services/product.service';

@Component({
  selector: 'app-create',
  templateUrl: './create.component.html',
  styleUrls: ['./create.component.css']
})
export class CreateComponent implements OnInit {

  jwt = "";

  constructor(
    private dialogRef: MatDialogRef<CreateComponent>,
    private prodService: ProductService,
    @Inject(MAT_DIALOG_DATA) data
  ) {
    this.jwt = data.jwt;
  }

  ngOnInit() {
    this.getAllProducts()
  }

  order: OrderDetail = {
    email: "",
    products: [],
    total: 0,
  }

  productsList: Product[] = [];
  getAllProducts() {
    this.prodService.getAllProducts(this.jwt).subscribe(resp => {
      console.table(resp)
      this.productsList = resp;
    }, error => {
      console.log("error-> " + error)
    })
  }

  selectedProd: Product;
  onSelectionChanged(prod: Product) {
    console.table(prod)
    console.log("index: " + 0)
    this.order.products[0].id_s = prod.id_s;
    this.order.products[0].name = prod.name;
    this.order.products[0].price = prod.price;
  }

  quantityChanged() {
    let total_tmp = 0;
    this.order.products.forEach((prod: ProductOrder) => {
      let priceProd = prod.price * prod.quantity;
      total_tmp = total_tmp + priceProd;
    })
    this.order.total = total_tmp;
  }

  addProduct() {
    console.table(this.selectedProd)

    let sameProd = this.order.products.find(x => x.id_p === this.selectedProd.id_s);

    if (this.selectedProd == null || sameProd != null) {
      return;
    }

    let prod_tmp: ProductOrder = {
      id: null,
      id_s: "",
      id_p: this.selectedProd.id_s,
      name: this.selectedProd.name,
      price: this.selectedProd.price,
      quantity: 1,
    }
    this.order.products.push(prod_tmp)
    this.quantityChanged()
  }

  delete(prod: ProductOrder) {
    this.order.products = this.order.products.filter(x => x != prod);
    this.quantityChanged()
  }

  save() {
    if (this.order.email == null || this.order.email == "" || this.order.total == null || this.order.products == null || this.order.products.length === 0) return;
    this.dialogRef.close(this.order);
  }

  close() {
    this.dialogRef.close();
  }

}

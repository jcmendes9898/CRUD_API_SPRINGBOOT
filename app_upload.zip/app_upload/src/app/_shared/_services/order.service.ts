import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable, throwError } from 'rxjs';
import { catchError, timeout } from 'rxjs/operators';
import { Datefilter, Order } from '../_model/order.model';

@Injectable({
  providedIn: 'root'
})
export class OrderService {

  constructor(
    private http: HttpClient
  ) { }

  private endpoint: String = "http://localhost:8080";

  getAllOrders(jwt): Observable<Order[]> {

    const httpOptions = {
      headers: new HttpHeaders({
        'Content-type': 'application/json',
        'Authorization': `Bearer ${jwt}`
      })
    }

    return this.http.get<Order[]>(`${this.endpoint}/getAllOrders`, httpOptions)
      .pipe(
        timeout(10000),
        catchError(this.handleError)
      )
  }

  getOrdersBetweenDates(jwt, dateFilter: Datefilter): Observable<Order[]> {
    const httpOptions = {
      headers: new HttpHeaders({
        'Content-type': 'application/json',
        'Authorization': `Bearer ${jwt}`
      })
    }

    return this.http.post<Order[]>(`${this.endpoint}/getAllOrders/betweenDates`, JSON.stringify(dateFilter), httpOptions)
      .pipe(
        timeout(10000),
        catchError(this.handleError)
      )
  }

  deleteOrder(jwt, id): Observable<any> {

    const httpOptions = {
      headers: new HttpHeaders({
        'Content-type': 'application/json',
        'Authorization': `Bearer ${jwt}`
      })
    }

    return this.http.delete<any>(`${this.endpoint}/order/${id}`, httpOptions)
      .pipe(
        timeout(10000),
        catchError(this.handleError)
      )
  }

  deleteProdOrder(jwt, id): Observable<any> {

    const httpOptions = {
      headers: new HttpHeaders({
        'Content-type': 'application/json',
        'Authorization': `Bearer ${jwt}`
      })
    }

    return this.http.delete<any>(`${this.endpoint}/prodOrder/${id}`, httpOptions)
      .pipe(
        timeout(10000),
        catchError(this.handleError)
      )
  }

  addOrder(jwt, order): Observable<Order> {

    const httpOptions = {
      headers: new HttpHeaders({
        'Content-type': 'application/json',
        'Authorization': `Bearer ${jwt}`
      })
    }

    return this.http.post<Order>(`${this.endpoint}/createOrder`, JSON.stringify(order), httpOptions)
      .pipe(
        timeout(10000),
        catchError(this.handleError)
      )
  }


  handleError(error) {
    let errorMessage = "";
    if (error.error instanceof ErrorEvent) {
      errorMessage = error.error.message; // client
    } else {
      errorMessage = `Error Code: ${error.status}\nMessage: ${error.message}`; //server
    }
    return throwError(errorMessage);
  }

}

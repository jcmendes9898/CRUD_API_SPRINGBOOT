import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable, throwError } from 'rxjs';
import { catchError, tap, timeout } from 'rxjs/operators';
import { HttpResponse } from '../_model/auth.model';

@Injectable({
  providedIn: 'root'
})
export class AuthService {

  constructor(
    private http: HttpClient
  ) { }

  private endpoint: string = "http://localhost:8080/auth";

  authentication(username, password): Observable<HttpResponse> {

    const httpOptions = {
      headers: new HttpHeaders({
        'Content-type': 'application/json',
      })
    }

    let content = {
      username: username,
      password: password
    }

    return this.http.post<HttpResponse>(this.endpoint, JSON.stringify(content), httpOptions)
      .pipe(
        catchError(this.handleError)
      )
  }

  handleError(error) {
    let errorMessage = "";
    if (error.error instanceof ErrorEvent) {
      errorMessage = error.error.message; // client
    } else {
      errorMessage = `Error Code: ${error.status}\nMessage: ${error.message}`; //server
    }
    return throwError(errorMessage);
  }

}

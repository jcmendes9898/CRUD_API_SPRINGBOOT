import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Observable, throwError } from 'rxjs';
import { Product } from '../_model/product.model';
import { timeout, catchError } from 'rxjs/operators';
@Injectable({
  providedIn: 'root'
})
export class ProductService {

  constructor(
    private http: HttpClient
  ) { }

  private endpoint: String = "http://localhost:8080";

  getAllProducts(jwt): Observable<Product[]> {

    const httpOptions = {
      headers: new HttpHeaders({
        'Content-type': 'application/json',
        'Authorization': `Bearer ${jwt}`
      })
    }

    return this.http.get<Product[]>(`${this.endpoint}/getAllProducts`, httpOptions)
      .pipe(
        timeout(10000),
        catchError(this.handleError)
      )
  }

  deleteProduct(jwt, id): Observable<any> {

    const httpOptions = {
      headers: new HttpHeaders({
        'Content-type': 'application/json',
        'Authorization': `Bearer ${jwt}`
      })
    }

    return this.http.delete<any>(`${this.endpoint}/product/${id}`, httpOptions)
      .pipe(
        timeout(10000),
        catchError(this.handleError)
      )
  }

  addProduct(jwt, prod): Observable<Product> {

    const httpOptions = {
      headers: new HttpHeaders({
        'Content-type': 'application/json',
        'Authorization': `Bearer ${jwt}`
      })
    }

    return this.http.post<Product>(`${this.endpoint}/createProduct`, JSON.stringify(prod), httpOptions)
      .pipe(
        timeout(10000),
        catchError(this.handleError)
      )
  }

  updateProduct(jwt, prod, id): Observable<Product> {

    const httpOptions = {
      headers: new HttpHeaders({
        'Content-type': 'application/json',
        'Authorization': `Bearer ${jwt}`
      })
    }

    return this.http.put<Product>(`${this.endpoint}/product/${id}`, JSON.stringify(prod), httpOptions)
      .pipe(
        timeout(10000),
        catchError(this.handleError)
      )
  }

  handleError(error) {
    let errorMessage = "";
    if (error.error instanceof ErrorEvent) {
      errorMessage = error.error.message; // client
    } else {
      errorMessage = `Error Code: ${error.status}\nMessage: ${error.message}`; //server
    }
    return throwError(errorMessage);
  }

}

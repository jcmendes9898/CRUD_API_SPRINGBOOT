
export interface Product {
    name: string;
    price: number;
    date_created: string;
    id_s: string;
}

export interface ProductDetail {
    name: string;
    price: number;
}
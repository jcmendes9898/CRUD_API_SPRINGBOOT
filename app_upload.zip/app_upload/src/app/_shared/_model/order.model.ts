export interface Order {
    id_s: string;
    email: string;
    total: number;
    date_created: Date;
    products: ProductOrder[];
}

export interface ProductOrder {
    id: string;
    id_s: string;
    id_p: string;
    name: string;
    price: number;
    quantity: number;
}

////////////////

export interface OrderDetail {
    email: string;
    total: number;
    products: ProductOrder[];
}

///////////////
export interface Datefilter {
    start_date: Date;
    end_date: Date;
}
export interface HttpResponse {
    jwt: string;
}